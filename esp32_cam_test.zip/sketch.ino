const int TRIG_PIN = 25;
const int ECHO_PIN = 26;
const int BUZZER_PIN = 27;

void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
}

void loop() {
  // Clear the trigger pin
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  
  // Set the trigger pin HIGH for 10 microseconds
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  
  // Read the echo pin
  long duration = pulseIn(ECHO_PIN, HIGH);
  
  // Calculate distance in centimeters
  float distance = duration * 0.034 / 2;
  
  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  // Obstacle detection logic with proper tone frequencies
  if (distance > 0 && distance < 30) {
    // Critical danger (under 30cm) -> Fast, high-pitched beep
    tone(BUZZER_PIN, 1500); // 1500 Hz tone frequency
    delay(100);
    noTone(BUZZER_PIN);    // Turn sound off
    delay(100);
  } else if (distance >= 30 && distance < 100) {
    // Warning zone (30cm to 100cm) -> Slower warning pulse
    tone(BUZZER_PIN, 1000); // 1000 Hz tone frequency
    delay(200);
    noTone(BUZZER_PIN);
    delay(300);
  } else {
    // Path is safe (over 100cm) -> Complete silence
    noTone(BUZZER_PIN);
    delay(200);
  }
}